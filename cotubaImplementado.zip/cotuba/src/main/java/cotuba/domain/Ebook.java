package cotuba.domain;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import cotuba.iterator.CapituloIterator;
import cotuba.iterator.Iterator;


public class Ebook {
	private String formato;
	private Path arquivoDeSaida;
	private List<Capitulo> capitulos;
	
	
	public Ebook() {
		this.capitulos = new ArrayList<Capitulo>();
	}
	
	public void adicionarCapitulo(Capitulo capitulo) {
		capitulos.add(capitulo);
	}
	
	public Iterator<Capitulo> criarIterator(){
		return new CapituloIterator(capitulos);
	}

	public String getFormato() {
		return formato;
	}

	public void setFormato(String formato) {
		this.formato = formato;
	}

	public Path getArquivoDeSaida() {
		return arquivoDeSaida;
	}

	public void setArquivoDeSaida(Path arquivoDeSaida) {
		this.arquivoDeSaida = arquivoDeSaida;
	}

	public List<Capitulo> getCapitulos() {
		return capitulos;
	}

	public void setCapitulos(List<Capitulo> capitulos) {
		this.capitulos = capitulos;
	}

	public boolean isUltimoCapitulo(Capitulo capitulo) {
		return this.capitulos.get(this.capitulos.size() - 1).equals(capitulo);
	}
	
	

}
