package cotuba.iterator;

import java.util.List;

import cotuba.domain.Capitulo;

public class CapituloIterator implements Iterator<Capitulo> {
    private List<Capitulo> capitulos;
    private int index;

    public CapituloIterator(List<Capitulo> capitulos) {
        this.capitulos = capitulos;
        this.index = 0;
    }

    @Override
    public boolean hasNext() {
        return index < capitulos.size();
    }

    @Override
    public Capitulo next() {
        if (hasNext()) {
            Capitulo capitulo = capitulos.get(index);
            index++;
            return capitulo;
        }
        return null; 

    }
}
	

