package cotuba.application;

import cotuba.domain.Ebook;

public interface GeradorEbook {
    public void gera(Ebook ebook);
    
    
}
