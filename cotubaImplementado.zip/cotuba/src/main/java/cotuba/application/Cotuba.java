package cotuba.application;

import java.nio.file.Path;
import java.util.List;

import cotuba.domain.Capitulo;
import cotuba.domain.Ebook;
import cotuba.epub.GeradorEPUB;
import cotuba.pdf.GeradorPDF;

public class Cotuba {

	public void executa(String formato, Path diretorioDosMD, Path arquivoDeSaida) {
		RenderizadorMDParaHTML renderizador = RenderizadorMDParaHTML.cria();
		List<Capitulo> capitulos = renderizador.renderiza(diretorioDosMD);
		Ebook ebook = new Ebook();
		//Iterator<Capitulo> iterator = ebook.criarIterator();

		
		ebook.setFormato(formato);
		ebook.setArquivoDeSaida(arquivoDeSaida);
		ebook.setCapitulos(capitulos);
		
		
		/*while(iterator.hasNext()) {
			Capitulo capitulo = iterator.next();
			System.out.println("Capitulos: " + capitulo.getTitulo());
		}*/

		GeradorEbook gerador;

		if ("pdf".equals(formato)) {
			gerador = new GeradorPDF();
		} else if ("epub".equals(formato)) {
			gerador = new GeradorEPUB();
		} else {
			throw new IllegalArgumentException("Formato do ebook inválido: " + formato);
		}

		gerador.gera(ebook);
	}

}
